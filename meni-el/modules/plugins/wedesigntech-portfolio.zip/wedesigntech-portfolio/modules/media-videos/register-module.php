<?php

if (!class_exists ( 'WDTPortfolioRegisterMediaVideosModule' )) {

	class WDTPortfolioRegisterMediaVideosModule extends WDTPortfolioAddon {

		private $module_name;
		private $module_url;

		/**
		 * Instance variable
		 */
		private static $_instance = null;

		/**
		 * Instance
		 *
		 * Ensures only one instance of the class is loaded or can be loaded.
		 */
		public static function instance() {

			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}

		function __construct() {

			$this->wdt_define_constants( 'WDT_MVIDEOS_PLUGIN_PATH', WDT_PLUGIN_PATH . 'modules/media-videos/' );
			$this->wdt_define_constants( 'WDT_MVIDEOS_PLUGIN_URL', WDT_PLUGIN_URL . 'modules/media-videos/' );

			add_filter ( 'wdt_metabox_tabs', array ( $this, 'wdt_metabox_tabs_tab' ) );

			add_action ( 'admin_enqueue_scripts', array ( $this, 'wdt_admin_enqueue_scripts' ), 120 );
			add_action ( 'wp_enqueue_scripts', array ( $this, 'wdt_enqueue_scripts' ), 130 );

			add_action ( 'wdt_addorupdate_listing_module', array ( $this, 'wdt_addorupdate_listing_mediavideos_module' ), 10, 2 );

			require_once WDT_MVIDEOS_PLUGIN_PATH . 'utils.php';
			require_once WDT_MVIDEOS_PLUGIN_PATH . 'shortcodes.php';
			require_once WDT_MVIDEOS_PLUGIN_PATH . 'dashboard.php';

		}

		function wdt_metabox_tabs_tab($tabs) {

			$tabs['media-videos'] = array (
				'label' => esc_html__('Media - Videos', 'wdt-portfolio'),
				'icon' => 'fas fa-camera-retro',
				'path' => WDT_MVIDEOS_PLUGIN_PATH . 'metabox-tab-listing.php'
			);

			return $tabs;

		}

		function wdt_admin_enqueue_scripts() {

			$this->wdt_register_dependent_files();

			$current_screen = get_current_screen();
			if($current_screen->id == 'wdt_listings') {
				wp_enqueue_style ( 'wdt-media-videos-fields' );
				wp_enqueue_script ( 'wdt-media-videos-fields' );
			}

		}

		function wdt_enqueue_scripts() {

			$this->wdt_register_dependent_files();
			$this->wdt_enqueue_registered_files();

			if(is_page_template('tpl-dashboard.php') || is_page_template('tpl-listing.php')) {
				wp_enqueue_media();
				wp_enqueue_style ( 'wdt-media-videos-fields' );
				wp_enqueue_script ( 'wdt-media-videos-fields' );
			}

		}

		function wdt_register_dependent_files() {

			wp_register_style ( 'wdt-media-videos-fields', WDT_MVIDEOS_PLUGIN_URL . 'assets/media-videos-fields.css', array ( 'wdt-fields' ) );
			wp_register_style ( 'wdt-media-videos-frontend', WDT_MVIDEOS_PLUGIN_URL . 'assets/media-videos-frontend.css', array ( 'fontawesome', 'material-icon', 'wdt-base', 'wdt-common', 'swiper' ) );

			wp_register_script ( 'wdt-media-videos-fields', WDT_MVIDEOS_PLUGIN_URL . 'assets/fields.js', array ('jquery', 'wdt-fields'), false, true );
			wp_register_script ( 'wdt-media-videos-frontend', WDT_MVIDEOS_PLUGIN_URL . 'assets/frontend.js', array ('jquery', 'wdt-frontend', 'swiper'), false, true );

		}

		function wdt_enqueue_registered_files() {

			wp_enqueue_style ( 'wdt-media-videos-frontend' );

			wp_enqueue_script ( 'wdt-media-videos-frontend' );

		}

		function wdt_addorupdate_listing_mediavideos_module($data, $listing_id) {

			extract($data);

			update_post_meta($listing_id, 'wdt_media_videos', $wdt_media_videos);

		}

	}

}

if( !function_exists('wdtMediaVideosModule') ) {
	function wdtMediaVideosModule() {
		return WDTPortfolioRegisterMediaVideosModule::instance();
	}
}

wdtMediaVideosModule();

?>