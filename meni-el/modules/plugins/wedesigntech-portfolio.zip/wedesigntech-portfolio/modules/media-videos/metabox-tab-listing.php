<div class="wdt-custom-box">

    <label><?php echo esc_html__('Add Videos', 'wdt-portfolio'); ?></label>
    <?php echo wdt_listing_media_videos_field($list_id); ?>

    <div class="wdt-note">
        <?php echo sprintf( esc_html__('Add videos for your %1$s here.', 'wdt-portfolio'), strtolower($listing_singular_label) ); ?>
    </div>

</div>