jQuery(document).ready(function() {

	"use strict";

	// Media Video

		jQuery('body').delegate('.wdt-add-media-videos-box', 'click', function(e) {

			var clone = jQuery('.wdt-media-videos-box-item-toclone').clone();
			clone.attr('class', 'wdt-media-videos-box-item').removeClass('hidden');
			clone.find('#wdt_media_videos').attr('name', 'wdt_media_videos[]').removeAttr('id').addClass('wdt_media_videos');

			clone.appendTo('.wdt-media-videos-box-item-holder');

			e.preventDefault();

		});

		jQuery('body').delegate('.wdt-remove-media-videos','click', function(e){

			jQuery(this).parents('.wdt-media-videos-box-item').remove();
			e.preventDefault();

		});

		if (jQuery().sortable) {
			jQuery('.wdt-media-videos-box-item-holder').sortable({
				placeholder: 'sortable-placeholder'
			});
		}

});