<?php

// Single Page - Media Videos
if(!function_exists('wdt_sp_media_videos')) {
	function wdt_sp_media_videos( $attrs, $content = null ) {

		$attrs = shortcode_atts ( array (

					'listing_id'                    => '',
					'class'                         => '',

					'carousel_effect'               => '',
					'carousel_slidesperview'        => 1,
					'carousel_loopmode'             => '',
					'carousel_mousewheelcontrol'    => '',
					'carousel_paginationtype'       => 'bullets',
					'carousel_arrowpagination'      => '',
					'carousel_arrowpagination_type' => 'type1',
					'carousel_spacebetween'         => '',

				), $attrs, 'wdt_sp_media_videos' );


		$output = '';

		if($attrs['listing_id'] == '' && is_singular('wdt_listings')) {
			global $post;
			$attrs['listing_id'] = $post->ID;
		}

		if($attrs['listing_id'] != '') {

			$media_carousel_attributes = array ();

			array_push($media_carousel_attributes, 'data-enablecarousel="true"');
			array_push($media_carousel_attributes, 'data-carouseleffect="'.$attrs['carousel_effect'].'"');
			array_push($media_carousel_attributes, 'data-carouselslidesperview="'.$attrs['carousel_slidesperview'].'"');
			array_push($media_carousel_attributes, 'data-carouselloopmode="'.$attrs['carousel_loopmode'].'"');
			array_push($media_carousel_attributes, 'data-carouselmousewheelcontrol="'.$attrs['carousel_mousewheelcontrol'].'"');
			array_push($media_carousel_attributes, 'data-carouselpaginationtype="'.$attrs['carousel_paginationtype'].'"');
			array_push($media_carousel_attributes, 'data-carouselarrowpagination="'.$attrs['carousel_arrowpagination'].'"');
			array_push($media_carousel_attributes, 'data-carouselspacebetween="'.$attrs['carousel_spacebetween'].'"');

			if(!empty($media_carousel_attributes)) {
				$media_carousel_attributes_string = implode(' ', $media_carousel_attributes);
			}


			$wdt_media_videos = get_post_meta($attrs['listing_id'], 'wdt_media_videos', true);
			$uniqid = uniqid();

			$output .= '<div class="wdt-listings-media-videos-holder '.$attrs['class'].'">';

				// Media Videos
				$output .= '<div class="wdt-listings-media-videos-container swiper-container" '.$media_carousel_attributes_string.'>';
					$output .= '<div class="wdt-listings-media-videos swiper-wrapper">';

									if(is_array($wdt_media_videos) && !empty($wdt_media_videos)) {
										$i = 0;
										foreach($wdt_media_videos as $wdt_media_video) {

											if(wp_oembed_get( $wdt_media_video ) != '') {
												$output .= '<div class="swiper-slide" data-hash="slide-'.$uniqid.$i.'">'.wp_oembed_get( $wdt_media_video ).'</div>';
											} else {
												$output .= '<div class="swiper-slide" data-hash="slide-'.$uniqid.$i.'">'.wp_video_shortcode( array('src' => $wdt_media_video) ).'</div>';
											}

											$i++;
										}
									}

					$output .= '</div>';

					$output .= '<div class="wdt-listings-swiper-pagination-holder">';

						if($attrs['carousel_paginationtype'] == 'bullets') {
							$output .= '<div class="wdt-swiper-bullet-pagination"></div>';
						}

						if($attrs['carousel_paginationtype'] == 'progressbar') {
							$output .= '<div class="wdt-swiper-progress-pagination"></div>';
						}

						if($attrs['carousel_paginationtype'] == 'fraction') {
							$output .= '<div class="wdt-swiper-fraction-pagination"></div>';
						}

						if($attrs['carousel_arrowpagination'] == 'true') {
							$output .= '<div class="wdt-swiper-arrow-pagination '.$attrs['carousel_arrowpagination_type'].'">';
								$output .= '<a href="#" class="wdt-swiper-arrow-prev"><span><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 20 20" style="enable-background:new 0 0 20 20;" xml:space="preserve"><g transform="translate(20.819 21)"><g><defs><rect x="-17.9" y="-20" width="14.2" height="18"></rect></defs><clipPath><use xlink:href="#SVGID_1_" style="overflow:visible;"></use></clipPath><g class="st0"><path d="M-5.2-19.9c0.4-0.3,1-0.1,1.3,0.3c0.2,0.3,0.2,0.7,0,1l-4.5,7c-0.2,0.4-0.2,0.8,0,1.2l4.5,7    c0.3,0.4,0.2,1-0.3,1.3c-0.3,0.2-0.7,0.2-1,0l-12.1-7.7c-0.7-0.4-0.9-1.3-0.4-2c0.1-0.2,0.3-0.3,0.4-0.4L-5.2-19.9z"></path></g></g></g></svg></span>'.esc_html__('Prev', 'wdt-portfolio').'</a>';
								$output .= '<a href="#" class="wdt-swiper-arrow-next"><span><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 20 20" style="enable-background:new 0 0 20 20;" xml:space="preserve"><g transform="translate(20.819 21)"><g><defs><rect x="-17.9" y="-20" width="14.2" height="18"></rect></defs><clipPath><use xlink:href="#SVGID_1_" style="overflow:visible;"></use>		</clipPath><g class="st0"><path d="M-16.5-2.1c-0.4,0.3-1,0.1-1.3-0.3c-0.2-0.3-0.2-0.7,0-1l4.5-7c0.2-0.4,0.2-0.8,0-1.2l-4.5-7c-0.3-0.4-0.2-1,0.3-1.3c0.3-0.2,0.7-0.2,1,0l12.1,7.7c0.7,0.4,0.9,1.3,0.4,2c-0.1,0.2-0.3,0.3-0.4,0.4L-16.5-2.1z"></path></g></g></g></svg></span>'.esc_html__('Next', 'wdt-portfolio').'</a>';
							$output .= '</div>';
						}

					$output .= '</div>';
				$output .= '</div>';

			$output .= '</div>';

		} else {

			$listing_singular_label = apply_filters( 'listing_label', 'singular' );

			$output .= sprintf( esc_html__('Please provide %1$s id to display corresponding data!', 'wdt-portfolio'), strtolower($listing_singular_label) );

		}

		return $output;

	}
	add_shortcode ( 'wdt_sp_media_videos', 'wdt_sp_media_videos' );
}

?>