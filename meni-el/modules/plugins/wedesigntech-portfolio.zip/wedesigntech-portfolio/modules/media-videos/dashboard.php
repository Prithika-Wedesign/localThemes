<?php

// Filter Listing Fields
if(!function_exists('wdt_add_listing_fields_from_mediavideos_module')) {
	function wdt_add_listing_fields_from_mediavideos_module($output = '', $edit_item_id = '') {

		$listing_singular_label = apply_filters( 'listing_label', 'singular' );

	    // Media - Videos
			$output .= '<div class="wdt-dashbord-section-holder">';

				$output .= '<div class="wdt-dashbord-section-holder-intro">';
					$output .= '<div class="wdt-dashbord-section-title">'.esc_html__('Media - Videos', 'wdt-portfolio').'</div>';
					$output .= '<div class="wdt-dashbord-section-title-notes">'.sprintf( esc_html__('You can add any number of videos for your %1$s.', 'wdt-portfolio'), strtolower($listing_singular_label) ).'</div>';
				$output .= '</div>';

				$output .= '<div class="wdt-dashbord-section-holder-content">';
					$output .= '<div class="wdt-dashboard-option-item">
									<label for="wdt_features">'.esc_html__('Add Videos', 'wdt-portfolio').'</label>
									<div class="wdt-dashboard-option-item-data">';
										$output .= wdt_listing_media_videos_field($edit_item_id);
						$output .= '</div>';
					$output .= '</div>';
				$output .= '</div>';

			$output .= '</div>';

	    return $output;

	}
	add_filter( 'wdt_add_listing_fields_from_modules', 'wdt_add_listing_fields_from_mediavideos_module', 10, 2 );
}

?>