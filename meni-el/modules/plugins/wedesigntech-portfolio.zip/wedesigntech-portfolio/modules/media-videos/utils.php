<?php

// Dashboard Media Videos Field
if(!function_exists('wdt_listing_media_videos_field')) {
    function wdt_listing_media_videos_field($item_id) {

        $output = '';

        $output .= '<div class="wdt-media-videos-box-container">';

            $output .= '<div class="wdt-media-videos-box-item-holder">';

                $wdt_media_videos = '';
                if($item_id > 0) {
                    $wdt_media_videos = get_post_meta($item_id, 'wdt_media_videos', true);
                }

                $j = 0;
                if(is_array($wdt_media_videos) && !empty($wdt_media_videos)) {
                    foreach($wdt_media_videos as $wdt_media_video) {

                        $output .= '<div class="wdt-media-videos-box-item">
                                        <div class="wdt-column wdt-one-column first">
                                            <input name="wdt_media_videos[]" class="wdt_media_videos" type="text" value="'.esc_attr($wdt_media_video).'" placeholder="'.esc_html__('Video', 'wdt-portfolio').'" />
                                        </div>
                                        <div class="wdt-media-videos-box-options">
                                            <span class="wdt-remove-media-videos"><span class="fas fa-times"></span></span>
                                            <span class="wdt-sort-media-videos"><span class="fas fa-arrows-alt"></span></span>
                                        </div>
                                    </div>';
                        $j++;
                    }
                }

            $output .= '</div>';

            $output .= '<a href="#" class="wdt-add-media-videos-box custom-button-style">'.esc_html__('Add Video', 'wdt-portfolio').'</a>';

            $output .= '<div class="wdt-media-videos-box-item-toclone hidden">
                            <div class="wdt-column wdt-one-column first">
                                <input id="wdt_media_videos" type="text" placeholder="'.esc_html__('Video', 'wdt-portfolio').'" />
                            </div>
                            <div class="wdt-media-videos-box-options">
                                <span class="wdt-remove-media-videos"><span class="fas fa-times"></span></span>
                                <span class="wdt-sort-media-videos"><span class="fas fa-arrows-alt"></span></span>
                            </div>
                        </div>';

        $output .= '</div>';

        return $output;

    }
}

?>