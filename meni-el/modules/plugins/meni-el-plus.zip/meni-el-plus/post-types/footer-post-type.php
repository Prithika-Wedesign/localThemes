<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if (! class_exists ( 'Meni_ElPlusFooterPostType' ) ) {

	class Meni_ElPlusFooterPostType {

        private static $_instance = null;

        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }

		function __construct() {

			add_action ( 'init', array( $this, 'meni_el_register_cpt' ) );
			add_filter ( 'template_include', array ( $this, 'meni_el_template_include' ) );
		}

		function meni_el_register_cpt() {

			$labels = array (
				'name'				 => __( 'Footers', 'meni-el-plus' ),
				'singular_name'		 => __( 'Footer', 'meni-el-plus' ),
				'menu_name'			 => __( 'Footers', 'meni-el-plus' ),
				'add_new'			 => __( 'Add Footer', 'meni-el-plus' ),
				'add_new_item'		 => __( 'Add New Footer', 'meni-el-plus' ),
				'edit'				 => __( 'Edit Footer', 'meni-el-plus' ),
				'edit_item'			 => __( 'Edit Footer', 'meni-el-plus' ),
				'new_item'			 => __( 'New Footer', 'meni-el-plus' ),
				'view'				 => __( 'View Footer', 'meni-el-plus' ),
				'view_item' 		 => __( 'View Footer', 'meni-el-plus' ),
				'search_items' 		 => __( 'Search Footers', 'meni-el-plus' ),
				'not_found' 		 => __( 'No Footers found', 'meni-el-plus' ),
				'not_found_in_trash' => __( 'No Footers found in Trash', 'meni-el-plus' ),
			);

			$args = array (
				'labels' 				=> $labels,
				'public' 				=> true,
				'exclude_from_search'	=> true,
				'show_in_nav_menus' 	=> false,
				'show_in_rest' 			=> true,
				'menu_position'			=> 26,
				'menu_icon' 			=> 'dashicons-editor-insertmore',
				'hierarchical' 			=> false,
				'supports' 				=> array ( 'title', 'editor', 'revisions' ),
			);

			register_post_type ( 'wdt_footers', $args );
		}

		function meni_el_template_include($template) {
			if ( is_singular( 'wdt_footers' ) ) {
				if ( ! file_exists ( get_stylesheet_directory () . '/single-wdt_footers.php' ) ) {
					$template = MENI_EL_PLUS_DIR_PATH . 'post-types/templates/single-wdt_footers.php';
				}
			}

			return $template;
		}
	}
}

Meni_ElPlusFooterPostType::instance();