<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if (! class_exists ( 'Meni_ElPlusHeaderPostType' ) ) {

	class Meni_ElPlusHeaderPostType {

        private static $_instance = null;

        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }

		function __construct() {

			add_action ( 'init', array( $this, 'meni_el_register_cpt' ), 5 );
			add_filter ( 'template_include', array ( $this, 'meni_el_template_include' ) );
		}

		function meni_el_register_cpt() {

			$labels = array (
				'name'				 => __( 'Headers', 'meni-el-plus' ),
				'singular_name'		 => __( 'Header', 'meni-el-plus' ),
				'menu_name'			 => __( 'Headers', 'meni-el-plus' ),
				'add_new'			 => __( 'Add Header', 'meni-el-plus' ),
				'add_new_item'		 => __( 'Add New Header', 'meni-el-plus' ),
				'edit'				 => __( 'Edit Header', 'meni-el-plus' ),
				'edit_item'			 => __( 'Edit Header', 'meni-el-plus' ),
				'new_item'			 => __( 'New Header', 'meni-el-plus' ),
				'view'				 => __( 'View Header', 'meni-el-plus' ),
				'view_item' 		 => __( 'View Header', 'meni-el-plus' ),
				'search_items' 		 => __( 'Search Headers', 'meni-el-plus' ),
				'not_found' 		 => __( 'No Headers found', 'meni-el-plus' ),
				'not_found_in_trash' => __( 'No Headers found in Trash', 'meni-el-plus' ),
			);

			$args = array (
				'labels' 				=> $labels,
				'public' 				=> true,
				'exclude_from_search'	=> true,
				'show_in_nav_menus' 	=> false,
				'show_in_rest' 			=> true,
				'menu_position'			=> 25,
				'menu_icon' 			=> 'dashicons-heading',
				'hierarchical' 			=> false,
				'supports' 				=> array ( 'title', 'editor', 'revisions' ),
			);

			register_post_type ( 'wdt_headers', $args );
		}

		function meni_el_template_include($template) {
			if ( is_singular( 'wdt_headers' ) ) {
				if ( ! file_exists ( get_stylesheet_directory () . '/single-wdt_headers.php' ) ) {
					$template = MENI_EL_PLUS_DIR_PATH . 'post-types/templates/single-wdt_headers.php';
				}
			}

			return $template;
		}
	}
}

Meni_ElPlusHeaderPostType::instance();