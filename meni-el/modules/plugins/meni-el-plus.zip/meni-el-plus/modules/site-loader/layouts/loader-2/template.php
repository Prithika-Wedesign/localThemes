<div class="pre-loader loader2">
    <div class="loader-inner">
        <span class="dot"></span>
        <span class="dot dot1"></span>
        <span class="dot dot2"></span>
        <span class="dot dot3"></span>
        <span class="dot dot4"></span>
    </div>
</div>