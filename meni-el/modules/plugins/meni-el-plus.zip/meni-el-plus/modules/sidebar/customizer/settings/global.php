<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'Meni_ElPlusGlobalSibarSettings' ) ) {
    class Meni_ElPlusGlobalSibarSettings {

        private static $_instance = null;

        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }

        function __construct() {
            add_filter( 'meni_el_plus_customizer_default', array( $this, 'default' ) );
            add_action( 'customize_register', array( $this, 'register' ), 15);
        }

        function default( $option ) {
            $option['global_sidebar_layout'] = 'content-full-width';
            $option['global_sidebar']        = '';
            $option['hide_standard_sidebar'] = '';
            return $option;
        }

        function register( $wp_customize ) {

            /**
             * Global Sidebar Panel
             */
            $wp_customize->add_section(
                new Meni_El_Customize_Section(
                    $wp_customize,
                    'site-global-sidebar-section',
                    array(
                        'title'    => esc_html__('Global Sidebar', 'meni-el-plus'),
                        'panel'    => 'site-widget-main-panel',
                        'priority' => 5
                    )
                )
            );

                /**
                 * Option: Global Sidebar Layout
                 */
                    $wp_customize->add_setting(
                        MENI_EL_CUSTOMISER_VAL . '[global_sidebar_layout]', array(
                            'type' => 'option',
                        )
                    );

                    $wp_customize->add_control( new Meni_El_Customize_Control_Radio_Image(
                        $wp_customize, MENI_EL_CUSTOMISER_VAL . '[global_sidebar_layout]', array(
                            'type'    => 'wdt-radio-image',
                            'label'   => esc_html__( 'Global Sidebar Layout', 'meni-el-plus'),
                            'section' => 'site-global-sidebar-section',
                            'choices' => apply_filters( 'meni_el_global_sidebar_layouts', array(
                                'content-full-width' => array(
                                    'label' => esc_html__( 'Without Sidebar', 'meni-el-plus' ),
                                    'path'  =>  MENI_EL_PLUS_DIR_URL . 'modules/sidebar/customizer/images/without-sidebar.png'
                                ),
                                'with-left-sidebar'  => array(
                                    'label' => esc_html__( 'With Left Sidebar', 'meni-el-plus' ),
                                    'path'  =>  MENI_EL_PLUS_DIR_URL . 'modules/sidebar/customizer/images/left-sidebar.png'
                                ),
                                'with-right-sidebar' => array(
                                    'label' => esc_html__( 'With Right Sidebar', 'meni-el-plus' ),
                                    'path'  =>  MENI_EL_PLUS_DIR_URL . 'modules/sidebar/customizer/images/right-sidebar.png'
                                ),
                            ) )
                        )
                    ) );

                /**
                 * Option : Hide Standard Sidebar
                 */
                $wp_customize->add_setting(
                    MENI_EL_CUSTOMISER_VAL . '[hide_standard_sidebar]', array(
                        'type' => 'option',
                    )
                );

                $wp_customize->add_control(
                    new Meni_El_Customize_Control_Switch(
                        $wp_customize, MENI_EL_CUSTOMISER_VAL . '[hide_standard_sidebar]', array(
                            'type'    => 'wdt-switch',
                            'section' => 'site-global-sidebar-section',
                            'label'   => esc_html__( 'Hide Standard Sidebar', 'meni-el-plus' ),
                            'choices' => array(
                                'on'  => esc_attr__( 'Yes', 'meni-el-plus' ),
                                'off' => esc_attr__( 'No', 'meni-el-plus' )
                            )
                        )
                    )
                );

                if ( ! defined( 'MENI_EL_PRO_VERSION' ) ) {
                    $wp_customize->add_control(
                        new Meni_El_Customize_Control_Separator(
                            $wp_customize, MENI_EL_CUSTOMISER_VAL . '[meni_el-plus-site-global-sidebar-separator]',
                            array(
                                'type'        => 'wdt-separator',
                                'section'     => 'site-global-sidebar-section',
                                'settings'    => array(),
                                'caption'     => MENI_EL_PLUS_REQ_CAPTION,
                                'description' => MENI_EL_PLUS_REQ_DESC,
                            )
                        )
                    );
                }

        }
    }
}

Meni_ElPlusGlobalSibarSettings::instance();