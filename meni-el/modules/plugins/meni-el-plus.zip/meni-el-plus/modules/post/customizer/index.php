<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'Meni_ElPlusCustomizerBlogPost' ) ) {
    class Meni_ElPlusCustomizerBlogPost {

        private static $_instance = null;

        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;
        }

        function __construct() {
			add_action( 'customize_register', array( $this, 'register' ), 15 );
        }

        function register( $wp_customize ) {

            $wp_customize->add_section(
                new Meni_El_Customize_Section(
                    $wp_customize,
                    'site-blog-post-section',
                    array(
                        'title'    => esc_html__('Single Post', 'meni-el-plus'),
                        'panel'    => 'site-blog-main-panel',
                        'priority' => 20,
                    )
                )
            );

			if ( ! defined( 'MENI_EL_PRO_VERSION' ) ) {
				$wp_customize->add_control(
					new Meni_El_Customize_Control_Separator(
						$wp_customize, MENI_EL_CUSTOMISER_VAL . '[meni_el-plus-site-single-blog-separator]',
						array(
							'type'        => 'wdt-separator',
							'section'     => 'site-blog-post-section',
							'settings'    => array(),
							'caption'     => MENI_EL_PLUS_REQ_CAPTION,
							'description' => MENI_EL_PLUS_REQ_DESC,
						)
					)
				);
			}

        }
    }
}

Meni_ElPlusCustomizerBlogPost::instance();