======= Meni_El Plus =====

Meni_El Plus plugin adds additonal features for Meni_El theme.


== Changelog ==

= 1.0.2 =

    * Notice error fixed

= 1.0.1 =

    * Importer error fixed

= 1.0.0 =

    * First release!