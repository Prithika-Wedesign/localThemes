===== Meni_El Shop =====

Meni_El Shop plugin adds shop features for Meni_El theme.


== Changelog ==

= 1.0.2 =

    * Fixed: Notice Error

= 1.0.1 =

    * Fixed: Deprecated Error

= 1.0.0 =

    * First release!