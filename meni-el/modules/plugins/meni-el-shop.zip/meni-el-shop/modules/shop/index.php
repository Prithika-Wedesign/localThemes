<?php

/**
 * Listings - Shop
 */


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'Meni_El_Shop_Listing_Shop' ) ) {

    class Meni_El_Shop_Listing_Shop {

        private static $_instance = null;

        private $settings;

        public static function instance() {

            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;

        }

        function __construct() {

            /* Load Modules */
                $this->load_modules();

        }

        /*
        Load Modules
        */
            function load_modules() {

                /* Customizer */
                    include_once MENI_EL_SHOP_PATH . 'modules/shop/customizer/index.php';

            }

    }

}


if( !function_exists('meni_el_shop_listing_shop') ) {
	function meni_el_shop_listing_shop() {
		return Meni_El_Shop_Listing_Shop::instance();
	}
}

meni_el_shop_listing_shop();