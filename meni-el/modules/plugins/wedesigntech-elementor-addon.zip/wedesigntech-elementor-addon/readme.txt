===== WeDesignTech Elementor Addon =====

WeDesignTech Elementor Addon plugin adds additional modules for Elementor plugin.


== Changelog ==

= 1.0.5 =

    * Fixed: External demo source update
    * Compatible with the latest Elementor Version

= 1.0.4 =

    * Fixed: Notice errors
    * Compatible with the latest Elementor Version

= 1.0.3 =

    * Fixed: Warnings and Deprecated errors
    * Compatible with the latest Elementor Version

= 1.0.2 =

    * Compatible: Latest elementor version

= 1.0.1 =

    * Compatible: Latest elementor version

= 1.0.0 =

    * First release!