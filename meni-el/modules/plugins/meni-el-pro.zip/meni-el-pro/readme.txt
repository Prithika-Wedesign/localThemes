===== Meni_El Pro =====

Meni_El Pro plugin adds advanced features for Meni_El theme.


== Changelog ==

= 1.0.3 =

    * Fixed: External demo source update

= 1.0.2 =

    * Added: Global Product Template For Single Product Page

= 1.0.1 =

    * Fixed: Enabling Header and Footer Options in elementor

= 1.0.0 =

    * First release!