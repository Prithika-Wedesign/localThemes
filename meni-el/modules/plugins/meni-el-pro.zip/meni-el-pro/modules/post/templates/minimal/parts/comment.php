<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<?php
if(  ! post_password_required() && ( comments_open() || get_comments_number() ) ) { ?>
	<!-- Entry Comment -->
		<div class="single-entry-comments">
		<div class="comment-wrap"><i class="fas fa-comment"></i><?php
			comments_popup_link(
				esc_html__('0', 'meni-el-pro'),
				esc_html__('1', 'meni-el-pro'),
				esc_html__('%', 'meni-el-pro'),
				'',
				esc_html__('Comments Off', 'meni-el-pro')
			); ?>
		</div>
	</div><!-- Entry Comment --><?php
}
?>