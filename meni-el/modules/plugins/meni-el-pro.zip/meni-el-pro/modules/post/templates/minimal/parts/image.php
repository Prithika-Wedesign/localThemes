<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<?php
	$post_meta = get_post_meta( $post_ID, '_meni_el_post_settings', TRUE );
	$post_meta = is_array( $post_meta ) ? $post_meta  : array();

	$post_format = !empty( $post_meta['post-format-type'] ) ? $post_meta['post-format-type'] : get_post_format();

	$template_args['post_ID'] = $post_ID;
	$template_args['meta'] = $post_meta;
	$template_args['enable_image_lightbox'] = $enable_image_lightbox; ?>

	<!-- Featured Image -->
	<div class="entry-thumb single-preview-img">
		<div class="blog-image"><?php meni_el_template_part( 'post', 'templates/post-format/post', $post_format, $template_args ); ?></div>
		
		<!-- Entry Categories -->
		<div class="single-entry-categories"><i class="fas fa-folder"></i><?php the_category(' '); ?></div>
		<!-- Entry Categories -->
		
		<!-- Entry Comment -->
			<div class="single-entry-comments">
			<div class="comment-wrap"><i class="fas fa-comment"></i><?php
				comments_popup_link(
					esc_html__('0', 'meni-el-pro'),
					esc_html__('1', 'meni-el-pro'),
					esc_html__('%', 'meni-el-pro'),
					'',
					esc_html__('Comments Off', 'meni-el-pro')
				); ?>
			</div>
		</div><!-- Entry Comment -->
		
		<!-- Post Format -->
		<div class="entry-format">
			<a class="ico-format" href="<?php echo esc_url(get_post_format_link( $post_format ));?>"></a>
		</div><!-- Post Format -->
	</div><!-- Featured Image -->