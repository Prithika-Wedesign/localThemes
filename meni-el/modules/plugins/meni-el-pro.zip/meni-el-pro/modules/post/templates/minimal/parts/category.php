<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<!-- Entry Categories -->
<div class="single-entry-categories"><?php the_category(' '); ?></div><!-- Entry Categories -->