<?php

/**
 * WooCommerce - Single - Module - Social Share & Follow - Customizer Settings
 */


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if( !class_exists( 'Meni_El_Shop_Customizer_Single_Social_Share_And_Follow' ) ) {

    class Meni_El_Shop_Customizer_Single_Social_Share_And_Follow {

        private static $_instance = null;

        public static function instance() {

            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }

            return self::$_instance;

        }

        function __construct() {

            add_filter( 'meni_el_woo_single_page_settings', array( $this, 'single_page_settings' ), 10, 1 );
            add_action( 'customize_register', array( $this, 'register' ), 15);

        }

        function single_page_settings( $settings ) {

            $product_show_sharer_facebook                = meni_el_customizer_settings('wdt-single-product-show-sharer-facebook' );
            $settings['product_show_sharer_facebook']    = $product_show_sharer_facebook;

            $product_show_sharer_delicious               = meni_el_customizer_settings('wdt-single-product-show-sharer-delicious' );
            $settings['product_show_sharer_delicious']   = $product_show_sharer_delicious;

            $product_show_sharer_digg                    = meni_el_customizer_settings('wdt-single-product-show-sharer-digg' );
            $settings['product_show_sharer_digg']        = $product_show_sharer_digg;

            $product_show_sharer_twitter                 = meni_el_customizer_settings('wdt-single-product-show-sharer-twitter' );
            $settings['product_show_sharer_twitter']     = $product_show_sharer_twitter;

            $product_show_sharer_linkedin                = meni_el_customizer_settings('wdt-single-product-show-sharer-linkedin' );
            $settings['product_show_sharer_linkedin']    = $product_show_sharer_linkedin;

            $product_show_sharer_pinterest               = meni_el_customizer_settings('wdt-single-product-show-sharer-pinterest' );
            $settings['product_show_sharer_pinterest']   = $product_show_sharer_pinterest;

            return $settings;

        }

        function register( $wp_customize ) {

            /**
            * Share
            */

                /**
                * Option : Sharer Description
                */
                    $wp_customize->add_setting(
                        MENI_EL_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-description]', array(
                            'type' => 'option'
                        )
                    );

                    $wp_customize->add_control(
                        new Meni_El_Customize_Control_Switch(
                            $wp_customize, MENI_EL_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-description]', array(
                                'type'        => 'wdt-description',
                                'label'       => esc_html__( 'Note: ', 'meni-el-pro'),
                                'section'     => 'woocommerce-single-page-sociable-share-section',
                                'description' => esc_html__( 'This option is applicable only for WooCommerce "Custom Template".', 'meni-el-pro')
                            )
                        )
                    );

                /**
                * Option : Show Facebook Sharer
                */
                    $wp_customize->add_setting(
                        MENI_EL_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-facebook]', array(
                            'type' => 'option'
                        )
                    );

                    $wp_customize->add_control(
                        new Meni_El_Customize_Control_Switch(
                            $wp_customize, MENI_EL_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-facebook]', array(
                                'type'    => 'wdt-switch',
                                'label'   => esc_html__( 'Show Facebook Sharer', 'meni-el-pro'),
                                'section' => 'woocommerce-single-page-sociable-share-section',
                                'choices' => array(
                                    'on'  => esc_attr__( 'Yes', 'meni-el-pro' ),
                                    'off' => esc_attr__( 'No', 'meni-el-pro' )
                                )
                            )
                        )
                    );

                /**
                * Option : Show Delicious Sharer
                */
                    $wp_customize->add_setting(
                        MENI_EL_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-delicious]', array(
                            'type' => 'option'
                        )
                    );

                    $wp_customize->add_control(
                        new Meni_El_Customize_Control_Switch(
                            $wp_customize, MENI_EL_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-delicious]', array(
                                'type'    => 'wdt-switch',
                                'label'   => esc_html__( 'Show Delicious Sharer', 'meni-el-pro'),
                                'section' => 'woocommerce-single-page-sociable-share-section',
                                'choices' => array(
                                    'on'  => esc_attr__( 'Yes', 'meni-el-pro' ),
                                    'off' => esc_attr__( 'No', 'meni-el-pro' )
                                )
                            )
                        )
                    );

                /**
                * Option : Show Digg Sharer
                */
                    $wp_customize->add_setting(
                        MENI_EL_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-digg]', array(
                            'type' => 'option'
                        )
                    );

                    $wp_customize->add_control(
                        new Meni_El_Customize_Control_Switch(
                            $wp_customize, MENI_EL_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-digg]', array(
                                'type'    => 'wdt-switch',
                                'label'   => esc_html__( 'Show Digg Sharer', 'meni-el-pro'),
                                'section' => 'woocommerce-single-page-sociable-share-section',
                                'choices' => array(
                                    'on'  => esc_attr__( 'Yes', 'meni-el-pro' ),
                                    'off' => esc_attr__( 'No', 'meni-el-pro' )
                                )
                            )
                        )
                    );

                /**
                * Option : Show Twitter Sharer
                */
                    $wp_customize->add_setting(
                        MENI_EL_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-twitter]', array(
                            'type' => 'option'
                        )
                    );

                    $wp_customize->add_control(
                        new Meni_El_Customize_Control_Switch(
                            $wp_customize, MENI_EL_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-twitter]', array(
                                'type'    => 'wdt-switch',
                                'label'   => esc_html__( 'Show Twitter Sharer', 'meni-el-pro'),
                                'section' => 'woocommerce-single-page-sociable-share-section',
                                'choices' => array(
                                    'on'  => esc_attr__( 'Yes', 'meni-el-pro' ),
                                    'off' => esc_attr__( 'No', 'meni-el-pro' )
                                )
                            )
                        )
                    );

                /**
                * Option : Show LinkedIn Sharer
                */
                    $wp_customize->add_setting(
                        MENI_EL_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-linkedin]', array(
                            'type' => 'option'
                        )
                    );

                    $wp_customize->add_control(
                        new Meni_El_Customize_Control_Switch(
                            $wp_customize, MENI_EL_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-linkedin]', array(
                                'type'    => 'wdt-switch',
                                'label'   => esc_html__( 'Show LinkedIn Sharer', 'meni-el-pro'),
                                'section' => 'woocommerce-single-page-sociable-share-section',
                                'choices' => array(
                                    'on'  => esc_attr__( 'Yes', 'meni-el-pro' ),
                                    'off' => esc_attr__( 'No', 'meni-el-pro' )
                                )
                            )
                        )
                    );

                /**
                * Option : Show Pinterest Sharer
                */
                    $wp_customize->add_setting(
                        MENI_EL_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-pinterest]', array(
                            'type' => 'option'
                        )
                    );

                    $wp_customize->add_control(
                        new Meni_El_Customize_Control_Switch(
                            $wp_customize, MENI_EL_CUSTOMISER_VAL . '[wdt-single-product-show-sharer-pinterest]', array(
                                'type'    => 'wdt-switch',
                                'label'   => esc_html__( 'Show Pinterest Sharer', 'meni-el-pro'),
                                'section' => 'woocommerce-single-page-sociable-share-section',
                                'choices' => array(
                                    'on'  => esc_attr__( 'Yes', 'meni-el-pro' ),
                                    'off' => esc_attr__( 'No', 'meni-el-pro' )
                                )
                            )
                        )
                    );

            /**
            * Follow
            */

                /**
                * Option : Follow Description
                */
                    $wp_customize->add_setting(
                        MENI_EL_CUSTOMISER_VAL . '[wdt-single-product-show-follow-description]', array(
                            'type' => 'option'
                        )
                    );

                    $wp_customize->add_control(
                        new Meni_El_Customize_Control_Switch(
                            $wp_customize, MENI_EL_CUSTOMISER_VAL . '[wdt-single-product-show-follow-description]', array(
                                'type'    => 'wdt-description',
                                'label'   => esc_html__( 'Note :', 'meni-el-pro'),
                                'section' => 'woocommerce-single-page-sociable-follow-section',
                                'description'   => esc_html__( 'This option is applicable only for WooCommerce "Custom Template".', 'meni-el-pro'),
                            )
                        )
                    );

                    $social_follow = array (
                        'delicious'   => esc_html__('Delicious', 'meni-el-pro'),
                        'deviantart'  => esc_html__('Deviantart', 'meni-el-pro'),
                        'digg'        => esc_html__('Digg', 'meni-el-pro'),
                        'dribbble'    => esc_html__('Dribbble', 'meni-el-pro'),
                        'envelope'    => esc_html__('Envelope', 'meni-el-pro'),
                        'facebook'    => esc_html__('Facebook', 'meni-el-pro'),
                        'flickr'      => esc_html__('Flickr', 'meni-el-pro'),
                        'google-plus' => esc_html__('Google Plus', 'meni-el-pro'),
                        'instagram'   => esc_html__('Instagram', 'meni-el-pro'),
                        'lastfm'      => esc_html__('Lastfm', 'meni-el-pro'),
                        'linkedin'    => esc_html__('Linkedin', 'meni-el-pro'),
                        'myspace'     => esc_html__('Myspace', 'meni-el-pro'),
                        'pinterest'   => esc_html__('Pinterest', 'meni-el-pro'),
                        'reddit'      => esc_html__('Reddit', 'meni-el-pro'),
                        'rss'         => esc_html__('RSS', 'meni-el-pro'),
                        'skype'       => esc_html__('Skype', 'meni-el-pro'),
                        'stumbleupon' => esc_html__('Stumbleupon', 'meni-el-pro'),
                        'tumblr'      => esc_html__('Tumblr', 'meni-el-pro'),
                        'twitter'     => esc_html__('Twitter', 'meni-el-pro'),
                        'viadeo'      => esc_html__('Viadeo', 'meni-el-pro'),
                        'vimeo'       => esc_html__('Vimeo', 'meni-el-pro'),
                        'yahoo'       => esc_html__('Yahoo', 'meni-el-pro'),
                        'youtube'     => esc_html__('Youtube', 'meni-el-pro')
                    );

                    foreach($social_follow as $socialfollow_key => $socialfollow) {

                        $wp_customize->add_setting(
                            MENI_EL_CUSTOMISER_VAL . '[wdt-single-product-show-follow-'.$socialfollow_key.']', array(
                                'type' => 'option'
                            )
                        );

                        $wp_customize->add_control(
                            new Meni_El_Customize_Control_Switch(
                                $wp_customize, MENI_EL_CUSTOMISER_VAL . '[wdt-single-product-show-follow-'.$socialfollow_key.']', array(
                                    'type'    => 'wdt-switch',
                                    'label'   => sprintf(esc_html__('Show %1$s Follow', 'meni-el-pro'), $socialfollow),
                                    'section' => 'woocommerce-single-page-sociable-follow-section',
                                    'choices' => array(
                                        'on'  => esc_attr__( 'Yes', 'meni-el-pro' ),
                                        'off' => esc_attr__( 'No', 'meni-el-pro' )
                                    )
                                )
                            )
                        );

                        $wp_customize->add_setting(
                            MENI_EL_CUSTOMISER_VAL . '[wdt-single-product-follow-'.$socialfollow_key.'-link]', array(
                                'type' => 'option'
                            )
                        );

                        $wp_customize->add_control(
                            new Meni_El_Customize_Control(
                                $wp_customize, MENI_EL_CUSTOMISER_VAL . '[wdt-single-product-follow-'.$socialfollow_key.'-link]', array(
                                    'type'       => 'text',
                                    'section'    => 'woocommerce-single-page-sociable-follow-section',
                                    'input_attrs' => array(
                                        'placeholder' => sprintf(esc_html__('%1$s Link', 'meni-el-pro'), $socialfollow)
                                    ),
                                    'dependency' => array ( 'wdt-single-product-show-follow-'.$socialfollow_key, '==', '1' )
                                )
                            )
                        );

                    }

        }

    }

}


if( !function_exists('meni_el_shop_customizer_single_social_share_and_follow') ) {
	function meni_el_shop_customizer_single_social_share_and_follow() {
		return Meni_El_Shop_Customizer_Single_Social_Share_And_Follow::instance();
	}
}

meni_el_shop_customizer_single_social_share_and_follow();