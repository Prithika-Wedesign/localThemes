<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.

CSFramework_Taxonomy::instance( array() );