<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.

CSFramework_Shortcode_Manager::instance( array() );